echo "8, K: $2"
./script_seed.sh $1 8 $2
echo "4, K: $2"
./script_seed.sh $1 4 $2
echo "2, K: $2"
./script_seed.sh $1 2 $2