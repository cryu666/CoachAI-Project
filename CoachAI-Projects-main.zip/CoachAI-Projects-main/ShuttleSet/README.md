# ShuttleSet: A Human-Annotated Stroke-Level Singles Dataset for Badminton Tactical Analysis (KDD 2023)
Official dataset of the paper **ShuttleSet: A Human-Annotated Stroke-Level Singles Dataset for Badminton Tactical Analysis**.
Paper: TBD